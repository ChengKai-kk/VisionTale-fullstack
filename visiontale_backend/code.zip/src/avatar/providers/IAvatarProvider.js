class IAvatarProvider {
  async stylize(input) { throw new Error("not implemented"); }
}

module.exports = { IAvatarProvider };
