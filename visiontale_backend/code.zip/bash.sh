zip -r code.zip . \
  -x "*.git*" \
  -x "*.DS_Store" \
  -x "*node_modules/.cache*"